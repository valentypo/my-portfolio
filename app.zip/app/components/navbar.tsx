"use client"

import { Button } from "@/components/ui/button"
import { Linkedin, Mail, Menu, X } from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { usePathname } from "next/navigation"

export function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const pathname = usePathname()

  const isActive = (path: string) => pathname === path

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/projects", label: "Projects" },
    { href: "/about", label: "About" },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-black/95 backdrop-blur supports-[backdrop-filter]:bg-black/60">
      <div className="container flex h-14 items-center justify-between">
        <Link className="text-lg font-bold cursor-target" href="/">
          SVT
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`cursor-target relative text-sm transition-all duration-200 hover:text-[#bee4ee] ${
                isActive(link.href)
                  ? "text-[#7ebfcf] transform -translate-y-[2px] after:absolute after:left-0 after:-bottom-1 after:h-[2px] after:w-full after:bg-[#7ebfcf] content-['']"
                  : ""
              }`}
            >
              {link.label}  
            </Link>
          ))}
          <Link href="/contact">
            <Button size="sm" className="cursor-target bg-[#508C9B] text-white hover:bg-[#508C9B]/80 transition-all duration-200">
              <Mail className="h-3 w-3 mr-1" />
              Contact Me
            </Button>
          </Link>
        </nav>

        {/* Mobile Toggle Button */}
        <button
          className="md:hidden p-2"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle mobile menu"
        >
          {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Nav */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-white/10 bg-black/95 backdrop-blur animate-in slide-in-from-top-2 duration-200">
          <nav className="container py-6 flex flex-col space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`relative text-sm px-3 py-3 rounded-md transition-all duration-200 hover:text-gray-300 ${
                  isActive(link.href)
                    ? "text-[#508C9B] bg-[#508C9B]/10 transform -translate-y-[1px] after:absolute after:left-3 after:bottom-2 after:h-[2px] after:w-[calc(100%-1.5rem)] after:bg-[#508C9B] content-['']"
                    : ""
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <div className="flex items-center justify-between pt-4 mt-2 border-t border-white/10">
              <Link href="/contact" onClick={() => setIsMobileMenuOpen(false)}>
                <Button size="sm" className="bg-[#508C9B] text-white hover:bg-[#508C9B]/80 transition-all duration-200">
                  <Mail className="h-3 w-3 mr-1" />
                  Contact Me
                </Button>
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
