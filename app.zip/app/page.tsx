"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Mail, ExternalLink, MapPin, ArrowRight, Github } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { Navbar } from "@/app/components/navbar"
import { Footer } from "@/app/components/footer"
import { motion } from "framer-motion"
import { Typewriter } from "react-simple-typewriter"

export default function Page() {
  return (
    <div className="min-h-screen bg-[#201E43] text-white">
      <Navbar />

      <main>
        {/* Hero Section */}
        <section className="flex min-h-[80vh] flex-col items-start justify-center px-4">
          <div className="container">
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="h-4 w-4 text-gray-400" />
              <span className="text-gray-400">Tangerang, ID</span>
            </div>
<h1 className="text-4xl sm:text-6xl font-bold tracking-tighter md:text-7xl mb-6 text-[#EEEEEE] leading-[1.1]">
  {/* STEVEN — bounce-in per letter */}
  <span className="flex gap-1">
    {"STEVEN".split("").map((char, index) => (
      <motion.span
        key={index}
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{
          delay: index * 0.05,
          type: "spring",
          stiffness: 500,
          damping: 30,
        }}
        className="inline-block"
      >
        {char}
      </motion.span>
    ))}
  </span>

  {/* VALENTINO TASLIM — typing + deleting effect */}
  <span className="block mt-1 text-[#71b0be]">
    <Typewriter
      words={["VALENTINO TASLIM"]}
      loop={0} // 0 = infinite loop
      typeSpeed={150}
      deleteSpeed={80}
      delaySpeed={4500}
      cursor
      cursorStyle="|"
    />
  </span>
</h1>

            <p className="text-lg sm:text-xl text-gray-300 max-w-2xl mb-8">
              Growing every day through code, exploring the intersection of software engineering and AI with curiosity
              and purpose.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/projects">
                <Button className="bg-[#508C9B] text-white hover:bg-[#508C9B]/90 cursor-target">VIEW MY PROJECTS</Button>
              </Link>
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 bg-transparent cursor-target">
                <ExternalLink className="h-4 w-4 mr-2" />
                Download CV
              </Button>
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section id="work" className="py-20 border-t border-white/10">
          <div className="container px-4">
            <div className="mb-12 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <h2 className="text-2xl sm:text-3xl font-bold">HIGHLIGHTED PROJECTS</h2>
              <Link href="/projects">
                <Button variant="outline" className="border-white/20 text-white hover:bg-white/10 bg-transparent cursor-target">
                  VIEW ALL PROJECTS
                  <ExternalLink className="h-4 w-4 ml-1" />
                </Button>
              </Link>
            </div>
            <div className="grid gap-8 md:grid-cols-2">
              <ProjectCard
                title="Wastara"
                subtitle="Web Development & AI Integration"
                description="Wastara is a mobile-first web app that lets citizens report trash and helps organizers coordinate cleanups with role-based accounts, location/photo reporting, and AI-assisted pickup optimization."
                image="https://sjc.microlink.io/cQ8W8G1lkG2hkjiD8wZeSZEyootEtct1xdcyWxP17gtgII7z-zB7gScmQgnIBrVuzEu3xb4VwBc1y3JrzSyAUg.jpeg"
                link="/work/california-dhcs"
                tags={["Web App", "Smart City", "AI Integration", "Geolocation"]}
              />
              <ProjectCard
                title="IRIS"
                subtitle="Mobile Application & AI-Driven Features"
                description="IRIS is a Flutter-based mobile app that helps the elderly and visually impaired navigate daily life by using AI for real-time object detection, text recognition, and voice feedback."
                image="https://sjc.microlink.io/cQ8W8G1lkG2hkjiD8wZeSZEyootEtct1xdcyWxP17gtgII7z-zB7gScmQgnIBrVuzEu3xb4VwBc1y3JrzSyAUg.jpeg"
                link="/work/united"
                tags={["Mobile App", "Computer Vision", "Text-to-Speech", "AI Integration"]}
              />
              <ProjectCard
                title="Student's Wellbeing Assesment"
                subtitle="Web Development & Machine Learning"
                description="Student Wellbeing Assessment is a Next.js web app that detects depression levels in students. We evaluated four tree-based models and chose XGBoost for its efficiency and accuracy, ensuring a lightweight, cross-platform experience."
                image="https://sjc.microlink.io/cQ8W8G1lkG2hkjiD8wZeSZEyootEtct1xdcyWxP17gtgII7z-zB7gScmQgnIBrVuzEu3xb4VwBc1y3JrzSyAUg.jpeg"
                link="/work/google"
                tags={["Enterprise UX", "Information Architecture", "Research"]}
              />
              <ProjectCard
                title="IMDB Sentiment Analysis"
                subtitle="NLP, Machine Learning & Transformers"
                description="IMDB Sentiment Analysis is an NLP project that classifies movie reviews as positive or negative. We compared traditional and transformer-based models, with RoBERTa achieving the best performance and an F1-score of around 89%."
                image="https://sjc.microlink.io/lb6PnrVoJlSjIWuX7CyOIoMFCW78cWbHFGCQP9uUYmz5ofv3y9SnR2NIks9iPw8UHHxogQQMMxj-xH47kVh6TA.jpeg"
                link="/work/janssen-pharmaceuticals"
                tags={["Design System", "Healthcare", "Enterprise UX"]}
              />
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-20 border-t border-white/10">
          <div className="container px-4">
            <div className="max-w-4xl">
              <h2 className="text-3xl sm:text-5xl font-bold mb-8">ABOUT ME</h2>
              <p className="text-lg sm:text-xl text-gray-300 leading-relaxed mb-8">
                Senior UX & Product Designer with 6+ years delivering AI-driven, scalable, and compliant solutions
                across healthcare, telecom, aviation, and enterprise platforms. Proven in transforming research and
                stakeholder insights into validated, measurable design outcomes. Adept in design systems, AI-enhanced
                workflows, and regulatory UX.
              </p>
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4 mb-8">
                <Card className="bg-gray-900 border-gray-800">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold mb-4 text-white">Design Tools</h3>
                    <div className="flex flex-wrap gap-2">
                      {["Figma", "Adobe XD", "Sketch", "InVision", "Photoshop"].map((skill) => (
                        <Badge key={skill} variant="secondary" className="bg-gray-800 text-gray-300">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-gray-900 border-gray-800">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold mb-4 text-white">Methodologies</h3>
                    <div className="flex flex-wrap gap-2">
                      {["Agile", "Lean", "Design Thinking"].map((skill) => (
                        <Badge key={skill} variant="secondary" className="bg-gray-800 text-gray-300">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-gray-900 border-gray-800">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold mb-4 text-white">Specializations</h3>
                    <div className="flex flex-wrap gap-2">
                      {["Accessibility (WCAG)", "Data Viz", "Design Systems"].map((skill) => (
                        <Badge key={skill} variant="secondary" className="bg-gray-800 text-gray-300">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-gray-900 border-gray-800">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold mb-4 text-white">Certification</h3>
                    <Badge className="bg-[#508C9B] text-white">Salesforce UX Certification</Badge>
                  </CardContent>
                </Card>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button className="bg-[#508C9B] text-white hover:bg-[#508C9B]/90">
                  <Mail className="h-4 w-4 mr-2" />
                  stevenv2605@gmail.com
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-32 bg-gray-900">
          <div className="container px-4 text-center">
            <Button variant="outline" className="mb-8 border-white/20 text-white hover:bg-white/10 bg-transparent">
              REACH OUT
            </Button>
            <h2 className="mb-6 text-4xl sm:text-6xl font-bold tracking-tighter md:text-8xl">
              GOT A COMPLEX
              <br />
              UX CHALLENGE?
            </h2>
            <p className="mb-8 text-base sm:text-lg text-gray-400">
              I'm open to new opportunities and would love to hear
              <br className="hidden sm:block" />
              about your project.
            </p>
            <Link href="/contact">
              <Button className="bg-[#508C9B] text-white hover:bg-[#508C9B]/80 text-lg px-8 py-6 h-auto">
                LET'S TALK
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

function ProjectCard({
  title,
  subtitle,
  description,
  image,
  link,
  tags,
}: {
  title: string
  subtitle: string
  description: string
  image: string
  link: string
  tags: string[]
}) {
  return (
    <Card className="bg-gray-900 border-gray-800 overflow-hidden hover:border-[#508C9B]/70 transition-all duration-300">
      <CardContent className="p-0">
        <div className="relative aspect-video w-full overflow-hidden border-b border-gray-800">
          <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent z-10" />
          <Image src={image || "/placeholder.svg"} alt={title} fill className="object-cover opacity-60" />
          <div className="absolute bottom-0 left-0 p-4 z-20">
            <h3 className="text-2xl font-bold text-white">{title}</h3>
            <p className="text-sm text-gray-300">{subtitle}</p>
          </div>
        </div>
        <div className="p-6">
          <p className="text-gray-300 mb-6 text-justify">{description}</p>
          <div className="flex flex-wrap gap-2 mb-6">
            {tags.map((tag) => (
              <Badge key={tag} variant="outline" className="border-[#508C9B]/50 text-gray-300">
                {tag}
              </Badge>
            ))}
          </div>
          <Link href={link}>
            <Button className="w-full bg-gray-800 hover:bg-gray-700 text-white">
              VIEW PROJECT
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}
