"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { Navbar } from "@/app/components/navbar"
import { Footer } from "@/app/components/footer"

export default function ProjectsPage() {
  return (
    <div className="min-h-screen bg-[#201E43] text-white">
      <Navbar />

      <main>
        {/* Projects Section */}
        <section className="py-20">
          <div className="container px-4">
            <div className="mb-12">
              <h1 className="text-4xl sm:text-6xl font-bold mb-6">MY PROJECTS</h1>
              <p className="text-lg sm:text-xl text-gray-300 max-w-2xl">
                A collection of my work spanning design systems, enterprise UX, and complex problem-solving across
                various industries.
              </p>
            </div>
            <div className="grid gap-8 md:grid-cols-2">
              <ProjectCard
                title="Wastara"
                subtitle="Web Development & AI Integration"
                description="Wastara is a mobile-first web app that lets citizens report trash and helps organizers coordinate cleanups with role-based accounts, location/photo reporting, and AI-assisted pickup optimization."
                image="https://sjc.microlink.io/cQ8W8G1lkG2hkjiD8wZeSZEyootEtct1xdcyWxP17gtgII7z-zB7gScmQgnIBrVuzEu3xb4VwBc1y3JrzSyAUg.jpeg"
                link="/work/california-dhcs"
                tags={["Web App", "Smart City", "AI Integration", "Geolocation"]}
              />
              <ProjectCard
                title="IRIS"
                subtitle="Mobile Application & AI-Driven Features"
                description="IRIS is a Flutter-based mobile app that helps the elderly and visually impaired navigate daily life by using AI for real-time object detection, text recognition, and voice feedback."
                image="https://sjc.microlink.io/cQ8W8G1lkG2hkjiD8wZeSZEyootEtct1xdcyWxP17gtgII7z-zB7gScmQgnIBrVuzEu3xb4VwBc1y3JrzSyAUg.jpeg"
                link="/work/united"
                tags={["Mobile App", "Computer Vision", "Text-to-Speech", "AI Integration"]}
              />
              <ProjectCard
                title="GOOGLE"
                subtitle="Customer Care Platform Unification"
                description="Simplified complex workflows for Google's customer care agents by integrating multiple systems into a cohesive, user-friendly dashboard that improved efficiency and reduced training time."
                image="https://sjc.microlink.io/cQ8W8G1lkG2hkjiD8wZeSZEyootEtct1xdcyWxP17gtgII7z-zB7gScmQgnIBrVuzEu3xb4VwBc1y3JrzSyAUg.jpeg"
                link="/work/google"
                tags={["Enterprise UX", "Information Architecture", "Research"]}
              />
              <ProjectCard
                title="JANSSEN PHARMACEUTICALS"
                subtitle="Healthcare Portal Redesign & Design System"
                description="Creating an FDA-compliant design system that unified 18 pharmaceutical brands across 2000+ screens, resulting in streamlined development processes and improved patient experiences."
                image="https://sjc.microlink.io/lb6PnrVoJlSjIWuX7CyOIoMFCW78cWbHFGCQP9uUYmz5ofv3y9SnR2NIks9iPw8UHHxogQQMMxj-xH47kVh6TA.jpeg"
                link="/work/janssen-pharmaceuticals"
                tags={["Design System", "Healthcare", "Enterprise UX"]}
              />
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

function ProjectCard({
  title,
  subtitle,
  description,
  image,
  link,
  tags,
}: {
  title: string
  subtitle: string
  description: string
  image: string
  link: string
  tags: string[]
}) {
  return (
    <Card className="bg-gray-900 border-gray-800 overflow-hidden hover:border-[#508C9B]/70 transition-all duration-300">
      <CardContent className="p-0">
        <div className="relative aspect-video w-full overflow-hidden border-b border-gray-800">
          <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent z-10" />
          <Image src={image || "/placeholder.svg"} alt={title} fill className="object-cover opacity-60" />
          <div className="absolute bottom-0 left-0 p-4 z-20">
            <h3 className="text-2xl font-bold text-white">{title}</h3>
            <p className="text-sm text-gray-300">{subtitle}</p>
          </div>
        </div>
        <div className="p-6">
          <p className="text-gray-300 mb-6 text-justify">{description}</p>
          <div className="flex flex-wrap gap-2 mb-6">
            {tags.map((tag) => (
              <Badge key={tag} variant="outline" className="border-[#508C9B]/50 text-gray-300">
                {tag}
              </Badge>
            ))}
          </div>
          <Link href={link}>
            <Button className="w-full bg-gray-800 hover:bg-gray-700 text-white">
              VIEW PROJECT
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}
