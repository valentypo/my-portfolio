import { cn } from "@/lib/utils"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import type React from "react"
import TargetCursor from "@/app/components/target-cursor" // ✅ import your cursor component

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Steven Valentino Taslim - AI & Software Engineer",
  description:
    "A student majoring in Computer Science. Currently invested in learning more about Artificial Intelligence and developing softwares!",
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark">
      <body className={cn("min-h-screen bg-black font-sans antialiased select-none [cursor:none]", inter.className)}>
        <TargetCursor /> {/* 👈 Inject the custom cursor globally */}
        {children}
      </body>
    </html>
  )
}